import React, { useState, useEffect } from 'react';
import { AppView, Part, Product } from './types';
import * as storageService from './services/storageService';
import Dashboard from './components/Dashboard';
import InventoryList from './components/InventoryList';
import ProductManager from './components/ProductManager';
import StorageAdvisor from './components/StorageAdvisor';
import DataSync from './components/DataSync';
import Tutorial from './components/Tutorial';
import { LayoutGrid, Package, Settings, Sliders, Archive, HelpCircle } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.DASHBOARD);
  const [parts, setParts] = useState<Part[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [hasApiKey, setHasApiKey] = useState(false);

  useEffect(() => {
    // Load initial data
    setParts(storageService.getParts());
    setProducts(storageService.getProducts());
    
    // Check for API Key (Simple check for this demo environment)
    if (process.env.API_KEY) {
      setHasApiKey(true);
    }
  }, []);

  const handleAddPart = (part: Part) => {
    storageService.savePart(part);
    setParts(storageService.getParts());
  };

  const handleUpdatePart = (part: Part) => {
    storageService.savePart(part);
    setParts(storageService.getParts());
  };

  const handleDeletePart = (id: string) => {
    storageService.deletePart(id);
    setParts(storageService.getParts());
  };

  const handleAddProduct = (product: Product) => {
    storageService.saveProduct(product);
    setProducts(storageService.getProducts());
  };

  const NavItem = ({ view, icon: Icon, label }: { view: AppView; icon: any; label: string }) => (
    <button
      onClick={() => setCurrentView(view)}
      className={`
        flex items-center gap-3 px-4 py-3 rounded-xl transition-all w-full
        ${currentView === view 
          ? 'bg-primary-100 text-primary-900 font-bold shadow-sm' 
          : 'text-primary-700 hover:bg-primary-50'}
      `}
    >
      <Icon size={20} strokeWidth={currentView === view ? 2.5 : 2} />
      <span>{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-primary-50 text-gray-800 flex flex-col md:flex-row font-sans">
      
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-white border-r border-primary-100 flex flex-col h-auto md:h-screen sticky top-0 z-10">
        <div className="p-6 border-b border-primary-50">
          <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-600 to-orange-600">
            AmberCraft
          </h1>
          <p className="text-xs text-primary-400 font-medium tracking-wide">工作室管家</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          <NavItem view={AppView.DASHBOARD} icon={LayoutGrid} label="概览" />
          <NavItem view={AppView.PRODUCTS} icon={Package} label="成品展示" />
          <NavItem view={AppView.INVENTORY_PARTS} icon={Archive} label="零件库存" />
          <NavItem view={AppView.STORAGE_OPTIMIZER} icon={Sliders} label="智能收纳" />
        </nav>

        <div className="p-4 border-t border-primary-50 space-y-2">
           <NavItem view={AppView.TUTORIAL} icon={HelpCircle} label="使用教程" />
           <NavItem view={AppView.SETTINGS} icon={Settings} label="同步与分享" />
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto h-screen">
        <div className="max-w-7xl mx-auto pb-10">
          {!hasApiKey && currentView !== AppView.SETTINGS && currentView !== AppView.TUTORIAL && (
            <div className="bg-red-100 border border-red-200 text-red-800 p-4 rounded-lg mb-6 flex items-center justify-between">
              <span>警告: 未检测到 Gemini API Key。AI 功能将无法使用。请确保环境变量中已配置。</span>
            </div>
          )}

          {currentView === AppView.DASHBOARD && (
            <Dashboard parts={parts} products={products} />
          )}

          {currentView === AppView.PRODUCTS && (
            <ProductManager 
              products={products} 
              allParts={parts}
              onAddProduct={handleAddProduct}
              onAddPart={handleAddPart}
            />
          )}

          {currentView === AppView.INVENTORY_PARTS && (
            <InventoryList 
              parts={parts}
              onAddPart={handleAddPart}
              onUpdatePart={handleUpdatePart}
              onDeletePart={handleDeletePart}
            />
          )}

          {currentView === AppView.STORAGE_OPTIMIZER && (
            <StorageAdvisor parts={parts} />
          )}

          {currentView === AppView.SETTINGS && (
            <DataSync />
          )}

          {currentView === AppView.TUTORIAL && (
            <Tutorial />
          )}
        </div>
      </main>
    </div>
  );
};

export default App;