export interface Part {
  id: string;
  name: string;
  category: string;
  stock: number;
  unit: string; // e.g., 'pcs', 'grams', 'cm'
  location: string; // e.g., "Box A-1", "Floor Bag 3"
  imageUrl?: string;
  minStockThreshold: number;
}

export interface ProductPart {
  partId: string; // References Part.id
  quantityRequired: number;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  imageUrl?: string;
  parts: ProductPart[]; // Composition of the product
  stockFinished: number; // Finished goods ready to ship
  price: number;
}

export interface StorageSuggestion {
  currentLocation: string;
  suggestedType: 'Drawer' | 'Bin' | 'Vertical Rack' | 'Hook' | 'Box';
  reasoning: string;
  priority: 'High' | 'Medium' | 'Low';
}

export enum AppView {
  DASHBOARD = 'DASHBOARD',
  INVENTORY_PARTS = 'INVENTORY_PARTS',
  PRODUCTS = 'PRODUCTS',
  STORAGE_OPTIMIZER = 'STORAGE_OPTIMIZER',
  SETTINGS = 'SETTINGS', // For data export/import
  TUTORIAL = 'TUTORIAL' // User guide
}

export interface GeminAnalysisResult {
  parts: {
    name: string;
    estimatedQuantity: number;
    category: string;
    material: string;
  }[];
  description: string;
}