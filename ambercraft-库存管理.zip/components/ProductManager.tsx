import React, { useState, useRef } from 'react';
import { Product, Part, ProductPart } from '../types';
import { analyzeProductImage } from '../services/geminiService';
import { Camera, Upload, Loader2, Save, Trash, AlertTriangle, Plus, PenTool } from 'lucide-react';

interface ProductManagerProps {
  products: Product[];
  allParts: Part[];
  onAddProduct: (product: Product) => void;
  onAddPart: (part: Part) => void;
}

const ProductManager: React.FC<ProductManagerProps> = ({ products, allParts, onAddProduct, onAddPart }) => {
  const [view, setView] = useState<'list' | 'ai-create' | 'manual-create'>('list');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // New Product State
  const [newProductImage, setNewProductImage] = useState<string | null>(null);
  const [newProductName, setNewProductName] = useState('');
  const [newProductDesc, setNewProductDesc] = useState('');
  const [newProductStock, setNewProductStock] = useState(0);
  
  // For AI Mode
  const [detectedParts, setDetectedParts] = useState<any[]>([]);
  
  // For Manual Mode
  const [manualParts, setManualParts] = useState<{partId: string, quantity: number}[]>([]);
  const [selectedPartId, setSelectedPartId] = useState<string>('');
  const [selectedPartQty, setSelectedPartQty] = useState<number>(1);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, isManual: boolean = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setNewProductImage(base64);
      
      if (!isManual) {
        // AI Mode logic
        setLoading(true);
        setError(null);
        try {
          const analysis = await analyzeProductImage(base64);
          setNewProductDesc(analysis.description || '');
          setDetectedParts(analysis.parts || []);
        } catch (err) {
          setError("AI 无法分析该图片。请重试或检查您的 API Key。");
        } finally {
          setLoading(false);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveAIProduct = () => {
    const finalProductParts: ProductPart[] = [];

    detectedParts.forEach(dp => {
      let existingPart = allParts.find(p => p.name.toLowerCase() === dp.name.toLowerCase());
      let partId = existingPart?.id;

      if (!existingPart) {
        const newPart: Part = {
          id: crypto.randomUUID(),
          name: dp.name,
          category: dp.category || '通用',
          stock: 0,
          unit: '个',
          location: '待整理',
          minStockThreshold: 5,
          imageUrl: '' // New parts from AI don't have images yet
        };
        onAddPart(newPart);
        partId = newPart.id;
      }

      if (partId) {
        finalProductParts.push({
          partId: partId,
          quantityRequired: dp.estimatedQuantity || 1
        });
      }
    });

    const newProduct: Product = {
      id: crypto.randomUUID(),
      name: newProductName || '新款饰品',
      description: newProductDesc,
      imageUrl: newProductImage || undefined,
      stockFinished: 0,
      price: 0,
      parts: finalProductParts
    };

    onAddProduct(newProduct);
    resetForm();
  };

  const handleSaveManualProduct = () => {
    const productParts: ProductPart[] = manualParts.map(mp => ({
      partId: mp.partId,
      quantityRequired: mp.quantity
    }));

    const newProduct: Product = {
      id: crypto.randomUUID(),
      name: newProductName,
      description: newProductDesc,
      imageUrl: newProductImage || undefined,
      stockFinished: newProductStock,
      price: 0,
      parts: productParts
    };

    onAddProduct(newProduct);
    resetForm();
  };

  const resetForm = () => {
    setView('list');
    setNewProductImage(null);
    setNewProductName('');
    setNewProductDesc('');
    setDetectedParts([]);
    setManualParts([]);
    setNewProductStock(0);
    setError(null);
  };

  const addManualPart = () => {
    if (!selectedPartId) return;
    const existingIndex = manualParts.findIndex(p => p.partId === selectedPartId);
    if (existingIndex >= 0) {
      const updated = [...manualParts];
      updated[existingIndex].quantity += selectedPartQty;
      setManualParts(updated);
    } else {
      setManualParts([...manualParts, { partId: selectedPartId, quantity: selectedPartQty }]);
    }
    setSelectedPartId('');
    setSelectedPartQty(1);
  };

  if (view === 'list') {
    return (
      <div className="space-y-6">
        <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h2 className="text-3xl font-bold text-primary-900">成品展示</h2>
            <p className="text-primary-700">您设计和制作的所有精美饰品。</p>
          </div>
          <div className="flex gap-3">
             <button 
              onClick={() => setView('manual-create')}
              className="bg-white text-primary-600 hover:bg-primary-50 border border-primary-200 px-4 py-2 rounded-full flex items-center gap-2 shadow-sm font-medium transition-all"
            >
              <PenTool size={18} />
              手动添加
            </button>
            <button 
              onClick={() => setView('ai-create')}
              className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-full flex items-center gap-2 shadow-lg transition-all"
            >
              <Camera size={18} />
              AI 识别新品
            </button>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map(prod => (
            <div key={prod.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-primary-100 hover:shadow-md transition-shadow">
               <div className="h-48 bg-gray-100 relative">
                 {prod.imageUrl ? (
                   <img src={prod.imageUrl} alt={prod.name} className="w-full h-full object-cover" />
                 ) : (
                   <div className="flex items-center justify-center h-full text-gray-400">无图片</div>
                 )}
                 <div className="absolute top-2 right-2 bg-white/90 px-2 py-1 rounded-md text-xs font-bold text-primary-800 shadow-sm">
                   成品库存: {prod.stockFinished}
                 </div>
               </div>
               <div className="p-5">
                 <h3 className="font-bold text-lg text-gray-900 mb-2">{prod.name}</h3>
                 <p className="text-sm text-gray-500 line-clamp-2 mb-4">{prod.description}</p>
                 <div className="flex flex-wrap gap-1">
                   {prod.parts.slice(0, 3).map((pp, idx) => {
                     const partName = allParts.find(p => p.id === pp.partId)?.name || '未知零件';
                     return (
                       <span key={idx} className="text-xs bg-primary-50 text-primary-700 px-2 py-1 rounded-full">
                         {partName}
                       </span>
                     );
                   })}
                   {prod.parts.length > 3 && <span className="text-xs text-gray-400 self-center">+{prod.parts.length - 3} 更多</span>}
                 </div>
               </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Common Image Uploader UI
  const ImageUploader = ({ isManual }: { isManual: boolean }) => (
    <div 
      className={`
        border-2 border-dashed rounded-2xl h-64 flex flex-col items-center justify-center cursor-pointer transition-colors relative overflow-hidden bg-gray-50
        ${newProductImage ? 'border-primary-500' : 'border-gray-300 hover:border-primary-400'}
      `}
      onClick={() => fileInputRef.current?.click()}
    >
      {newProductImage ? (
        <img src={newProductImage} alt="Preview" className="w-full h-full object-contain" />
      ) : (
        <>
          <Upload size={32} className="text-gray-400 mb-2" />
          <p className="text-gray-500 text-sm">点击上传照片</p>
        </>
      )}
      
      {loading && !isManual && (
        <div className="absolute inset-0 bg-white/80 flex flex-col items-center justify-center">
          <Loader2 className="animate-spin text-primary-600 mb-2" size={32} />
          <p className="text-primary-800 font-medium">正在分析成分...</p>
        </div>
      )}
      <input 
        type="file" 
        ref={fileInputRef} 
        className="hidden" 
        accept="image/*" 
        onChange={(e) => handleImageUpload(e, isManual)} 
      />
    </div>
  );

  // VIEW: MANUAL CREATE
  if (view === 'manual-create') {
    return (
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl border border-primary-100 overflow-hidden">
        <div className="p-6 border-b border-primary-100 bg-primary-50 flex justify-between items-center">
          <h2 className="text-xl font-bold text-primary-900 flex items-center gap-2">
            <PenTool size={20}/> 手动添加新产品
          </h2>
          <button onClick={resetForm} className="text-gray-500 hover:text-gray-800">取消</button>
        </div>
        
        <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
           <div className="space-y-4">
              <ImageUploader isManual={true} />
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">产品名称</label>
                <input 
                  type="text" 
                  className="w-full p-2 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none"
                  placeholder="例如：夏日琥珀项链"
                  value={newProductName}
                  onChange={e => setNewProductName(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">成品库存</label>
                <input 
                  type="number" 
                  className="w-full p-2 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none"
                  value={newProductStock}
                  onChange={e => setNewProductStock(parseInt(e.target.value) || 0)}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">描述</label>
                <textarea 
                  className="w-full p-2 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none h-24"
                  value={newProductDesc}
                  onChange={e => setNewProductDesc(e.target.value)}
                />
              </div>
           </div>

           <div className="bg-gray-50 rounded-xl p-6 h-full flex flex-col">
              <h3 className="font-semibold text-gray-800 mb-4">组成零件 (BOM)</h3>
              <p className="text-xs text-gray-500 mb-4">从您的库存中选择组装此产品所需的零件。</p>
              
              <div className="flex gap-2 mb-4">
                <select 
                  className="flex-1 p-2 bg-white border border-gray-300 rounded-lg text-sm"
                  value={selectedPartId}
                  onChange={e => setSelectedPartId(e.target.value)}
                >
                  <option value="">-- 选择零件 --</option>
                  {allParts.map(p => (
                    <option key={p.id} value={p.id}>{p.name} (库存: {p.stock} {p.unit})</option>
                  ))}
                </select>
                <input 
                  type="number" 
                  className="w-20 p-2 bg-white border border-gray-300 rounded-lg text-sm"
                  placeholder="数量"
                  min="1"
                  value={selectedPartQty}
                  onChange={e => setSelectedPartQty(parseInt(e.target.value) || 1)}
                />
                <button 
                  onClick={addManualPart}
                  disabled={!selectedPartId}
                  className="bg-primary-600 text-white p-2 rounded-lg hover:bg-primary-700 disabled:opacity-50"
                >
                  <Plus size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2 max-h-[300px]">
                {manualParts.map((mp, idx) => {
                  const partName = allParts.find(p => p.id === mp.partId)?.name || '未知零件';
                  return (
                    <div key={idx} className="bg-white p-3 rounded-lg border border-gray-200 shadow-sm flex justify-between items-center">
                      <span className="text-gray-800">{partName}</span>
                      <div className="flex items-center gap-3">
                         <span className="font-bold text-sm bg-gray-100 px-2 py-1 rounded">x{mp.quantity}</span>
                         <button 
                           onClick={() => setManualParts(manualParts.filter((_, i) => i !== idx))}
                           className="text-gray-400 hover:text-red-500"
                         >
                           <Trash size={16} />
                         </button>
                      </div>
                    </div>
                  );
                })}
                {manualParts.length === 0 && (
                  <div className="text-center text-gray-400 py-4 text-sm">暂无添加零件</div>
                )}
              </div>
              
              <button 
                onClick={handleSaveManualProduct}
                disabled={!newProductName}
                className="w-full py-3 mt-6 rounded-xl font-bold text-white shadow-lg bg-primary-600 hover:bg-primary-700 disabled:bg-gray-300 disabled:cursor-not-allowed flex justify-center items-center gap-2"
              >
                <Save size={20} />
                保存产品
              </button>
           </div>
        </div>
      </div>
    );
  }

  // VIEW: AI CREATE
  return (
    <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl border border-primary-100 overflow-hidden">
      <div className="p-6 border-b border-primary-100 bg-primary-50 flex justify-between items-center">
        <h2 className="text-xl font-bold text-primary-900 flex items-center gap-2">
          <Camera size={20}/> AI 识别添加新产品
        </h2>
        <button onClick={resetForm} className="text-gray-500 hover:text-gray-800">取消</button>
      </div>
      
      <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <ImageUploader isManual={false} />

          {error && (
            <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg flex items-start gap-2">
              <AlertTriangle size={16} className="mt-0.5" />
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">产品名称</label>
            <input 
              type="text" 
              className="w-full p-2 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none"
              placeholder="例如：夏日琥珀项链"
              value={newProductName}
              onChange={e => setNewProductName(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">描述</label>
            <textarea 
              className="w-full p-2 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none h-24"
              placeholder="AI 将自动生成描述..."
              value={newProductDesc}
              onChange={e => setNewProductDesc(e.target.value)}
            />
          </div>
        </div>

        <div className="bg-gray-50 rounded-xl p-6 h-full flex flex-col">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-primary-500"></span>
            检测到的组件
          </h3>
          
          <div className="flex-1 overflow-y-auto space-y-3">
             {detectedParts.length === 0 ? (
               <div className="text-center text-gray-400 py-10 text-sm">
                 上传图片后，这里会显示分析出的零件清单。
               </div>
             ) : (
               detectedParts.map((part, idx) => (
                 <div key={idx} className="bg-white p-3 rounded-lg border border-gray-200 shadow-sm flex justify-between items-center group">
                   <div>
                     <p className="font-medium text-gray-800">{part.name}</p>
                     <p className="text-xs text-gray-500">{part.category} • {part.material}</p>
                   </div>
                   <div className="flex items-center gap-3">
                     <span className="text-sm font-bold bg-gray-100 px-2 py-1 rounded">x{part.estimatedQuantity}</span>
                     <button 
                       onClick={() => setDetectedParts(detectedParts.filter((_, i) => i !== idx))}
                       className="text-gray-300 hover:text-red-500 transition-colors"
                     >
                       <Trash size={16} />
                     </button>
                   </div>
                 </div>
               ))
             )}
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
             <button 
               onClick={handleSaveAIProduct}
               disabled={!newProductName || detectedParts.length === 0}
               className={`w-full py-3 rounded-xl font-bold text-white shadow-lg flex justify-center items-center gap-2 transition-all
                 ${(!newProductName || detectedParts.length === 0) ? 'bg-gray-300 cursor-not-allowed' : 'bg-primary-600 hover:bg-primary-700'}
               `}
             >
               <Save size={20} />
               保存成品并生成零件
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductManager;