import React, { useState } from 'react';
import { Part } from '../types';
import { suggestStorageOptimization } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';
import { Sparkles, ArrowRight, Box } from 'lucide-react';

interface StorageAdvisorProps {
  parts: Part[];
}

const StorageAdvisor: React.FC<StorageAdvisorProps> = ({ parts }) => {
  const [advice, setAdvice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGetAdvice = async () => {
    setLoading(true);
    const result = await suggestStorageOptimization(parts);
    setAdvice(result);
    setLoading(false);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <header className="text-center space-y-4 py-8">
        <div className="inline-block p-4 rounded-full bg-amber-100 text-amber-700 mb-2">
          <Sparkles size={32} />
        </div>
        <h2 className="text-3xl font-bold text-primary-900">智能收纳顾问</h2>
        <p className="text-lg text-primary-800 max-w-2xl mx-auto">
          "现在零件都堆在地板上..." —— 没问题，交给我们。
          让 AI 分析您的库存，为您提供专业的整理收纳方案。
        </p>
      </header>

      {!advice ? (
        <div className="flex justify-center">
          <button 
            onClick={handleGetAdvice}
            disabled={loading}
            className="bg-primary-600 hover:bg-primary-700 text-white text-lg font-bold px-8 py-4 rounded-2xl shadow-xl transition-transform transform hover:-translate-y-1 flex items-center gap-3"
          >
            {loading ? (
              <>思考中...</>
            ) : (
              <>生成收纳方案 <ArrowRight /></>
            )}
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-xl border border-primary-100 overflow-hidden">
          <div className="bg-primary-600 p-4 text-white font-bold flex items-center gap-2">
            <Box size={20} />
            您的专属整理计划
          </div>
          <div className="p-8 prose prose-amber max-w-none">
            <ReactMarkdown>{advice}</ReactMarkdown>
          </div>
          <div className="p-6 bg-gray-50 border-t border-gray-100 flex justify-end">
             <button 
               onClick={() => setAdvice(null)}
               className="text-primary-700 font-semibold hover:underline"
             >
               重新开始
             </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
        <div className="bg-white/60 p-6 rounded-xl border border-primary-100/50 backdrop-blur-sm">
          <h4 className="font-bold text-primary-900 mb-2">1. 分析</h4>
          <p className="text-sm text-primary-800">分析您的零件种类、数量和当前（混乱的）位置。</p>
        </div>
        <div className="bg-white/60 p-6 rounded-xl border border-primary-100/50 backdrop-blur-sm">
          <h4 className="font-bold text-primary-900 mb-2">2. 分类</h4>
          <p className="text-sm text-primary-800">按使用频率和材料类型（如珠子 vs 金属件）进行逻辑分组。</p>
        </div>
        <div className="bg-white/60 p-6 rounded-xl border border-primary-100/50 backdrop-blur-sm">
          <h4 className="font-bold text-primary-900 mb-2">3. 建议</h4>
          <p className="text-sm text-primary-800">推荐具体的容器，如“24格亚克力盒”或“立式洞洞板”。</p>
        </div>
      </div>
    </div>
  );
};

export default StorageAdvisor;