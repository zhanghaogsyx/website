import React from 'react';
import { Camera, Box, Share2, Search, Sliders, Globe, Laptop } from 'lucide-react';

const Tutorial: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in pb-12">
      <header className="text-center py-6">
        <h2 className="text-3xl font-bold text-primary-900">使用教程 & 帮助</h2>
        <p className="text-primary-700 mt-2">如何使用 AmberCraft 管理您的手工饰品生意</p>
      </header>

      <div className="space-y-6">
        {/* Step 1 */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-primary-100">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-amber-100 text-amber-700 rounded-xl shrink-0 mt-1">
              <Camera size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">1. 货品识别与拆分</h3>
              <p className="text-gray-600 mb-3">
                您无需手动输入每一个零件。在 <strong>“成品展示”</strong> 页面，点击 <strong>“AI 识别新品”</strong>。
              </p>
              <ul className="list-disc list-inside text-sm text-gray-500 space-y-1 ml-1">
                <li>上传您的成品饰品图片（如手链、耳环）。</li>
                <li>AI 会自动识别图中的珠子、配件、材质。</li>
                <li>您可以检查并修改识别结果，然后点击保存。</li>
                <li>系统会自动将这些零件加入到您的“零件库存”中，无需重复录入。</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Step 2 */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-primary-100">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-blue-100 text-blue-700 rounded-xl shrink-0 mt-1">
              <Search size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">2. 零件库存管理</h3>
              <p className="text-gray-600 mb-3">
                在 <strong>“零件库存”</strong> 页面，您可以查看所有零散配件。
              </p>
              <ul className="list-disc list-inside text-sm text-gray-500 space-y-1 ml-1">
                <li>支持按名称或分类（如“珠子”、“扣环”）搜索。</li>
                <li>点击编辑图标可修改库存数量、位置。</li>
                <li>设置“预警阈值”，当库存不足时，首页概览会变成红色提醒您补货。</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Step 3 */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-primary-100">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-purple-100 text-purple-700 rounded-xl shrink-0 mt-1">
              <Sliders size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">3. 智能收纳优化</h3>
              <p className="text-gray-600 mb-3">
                零件太多，地上摆不下了？去 <strong>“智能收纳顾问”</strong> 页面。
              </p>
              <ul className="list-disc list-inside text-sm text-gray-500 space-y-1 ml-1">
                <li>点击“生成收纳方案”。</li>
                <li>AI 会读取您目前所有的库存清单。</li>
                <li>它会建议您购买什么样的盒子、如何分类摆放最高效（例如：常用珠子放手边，备用金属件放底层抽屉）。</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Step 4 */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-primary-100">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-green-100 text-green-700 rounded-xl shrink-0 mt-1">
              <Share2 size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">4. 备份与数据传输</h3>
              <p className="text-gray-600 mb-3">
                想把数据带回家，或者发给员工？使用 <strong>“同步与分享”</strong> 功能。
              </p>
              <ul className="list-disc list-inside text-sm text-gray-500 space-y-1 ml-1">
                <li>点击 <strong>“导出数据”</strong>，会生成一个 JSON 文件。</li>
                <li>将这个文件通过微信、邮件发给其他人，或存入U盘。</li>
                <li>在另一台电脑打开本网页，选择 <strong>“导入数据”</strong> 并上传该文件，即可完全同步所有库存信息。</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Step 5: Deployment Guide */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-primary-100 bg-gradient-to-r from-orange-50 to-white">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-orange-100 text-orange-700 rounded-xl shrink-0 mt-1">
              <Globe size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">5. 如何给他人使用 / 本地运行</h3>
              <p className="text-gray-600 mb-3">
                由于本系统包含 AI 功能和现代网页技术，<strong>直接双击打开 HTML 文件通常无法运行</strong>。请选择以下一种方式：
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="bg-white p-4 rounded-xl border border-orange-200">
                  <h4 className="font-bold text-orange-800 flex items-center gap-2 mb-2">
                    <Globe size={16}/> 推荐：在线托管 (最简单)
                  </h4>
                  <p className="text-sm text-gray-600 mb-2">
                    将本程序的所有文件上传到免费的静态网页托管平台，例如 <strong>Vercel</strong> 或 <strong>Netlify</strong>。
                  </p>
                  <ol className="list-decimal list-inside text-sm text-gray-500 space-y-1">
                    <li>注册一个 Netlify/Vercel 账号。</li>
                    <li>将包含这些代码的文件夹拖入上传区域。</li>
                    <li>它会生成一个网址 (如 <code>my-shop.netlify.app</code>)。</li>
                    <li>将这个网址发给您的朋友即可使用，手机电脑都能开。</li>
                  </ol>
                </div>

                <div className="bg-white p-4 rounded-xl border border-gray-200">
                  <h4 className="font-bold text-gray-800 flex items-center gap-2 mb-2">
                    <Laptop size={16}/> 进阶：本地电脑运行
                  </h4>
                  <p className="text-sm text-gray-600 mb-2">
                    如果必须在没有网络的局域网使用（注意：AI功能仍需外网）：
                  </p>
                  <ul className="list-disc list-inside text-sm text-gray-500 space-y-1">
                    <li>需要一个“本地服务器”环境。</li>
                    <li>如果您安装了 VS Code，请安装 <strong>"Live Server"</strong> 插件，右键 index.html 选择 "Open with Live Server"。</li>
                    <li>或者安装 Node.js，在文件夹运行 <code>npx serve</code>。</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Tutorial;