import React from 'react';
import { Part, Product } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Package, Layers, AlertCircle } from 'lucide-react';

interface DashboardProps {
  parts: Part[];
  products: Product[];
}

const Dashboard: React.FC<DashboardProps> = ({ parts, products }) => {
  const lowStockParts = parts.filter(p => p.stock <= p.minStockThreshold);
  const totalFinishedValue = products.reduce((acc, curr) => acc + (curr.price * curr.stockFinished), 0);

  // Prepare data for chart: Stock levels of top 5 parts by quantity
  const chartData = [...parts]
    .sort((a, b) => b.stock - a.stock)
    .slice(0, 5)
    .map(p => ({
      name: p.name.length > 8 ? p.name.substring(0, 8) + '...' : p.name,
      stock: p.stock
    }));

  return (
    <div className="space-y-6 animate-fade-in">
      <header className="mb-8">
        <h2 className="text-3xl font-bold text-primary-900">工作台概览</h2>
        <p className="text-primary-700">欢迎回到你的工作室，今天也要元气满满哦！</p>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-primary-100 flex items-center space-x-4">
          <div className="p-3 bg-blue-100 text-blue-600 rounded-full">
            <Package size={24} />
          </div>
          <div>
            <p className="text-sm text-gray-500">成品款式</p>
            <h3 className="text-2xl font-bold text-gray-800">{products.length} 款</h3>
            <p className="text-xs text-gray-400">预估价值: ¥{totalFinishedValue.toFixed(2)}</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-primary-100 flex items-center space-x-4">
          <div className="p-3 bg-amber-100 text-amber-600 rounded-full">
            <Layers size={24} />
          </div>
          <div>
            <p className="text-sm text-gray-500">零件种类</p>
            <h3 className="text-2xl font-bold text-gray-800">{parts.length} 种</h3>
            <p className="text-xs text-gray-400">原材料库存</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-primary-100 flex items-center space-x-4">
          <div className="p-3 bg-red-100 text-red-600 rounded-full">
            <AlertCircle size={24} />
          </div>
          <div>
            <p className="text-sm text-gray-500">库存预警</p>
            <h3 className="text-2xl font-bold text-gray-800">{lowStockParts.length} 项</h3>
            <p className="text-xs text-gray-400">需要补货</p>
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-primary-100">
          <h3 className="text-lg font-semibold text-primary-900 mb-4">库存量排行 (Top 5)</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                <XAxis dataKey="name" tick={{fontSize: 12, fill: '#78716c'}} axisLine={false} tickLine={false} />
                <YAxis tick={{fontSize: 12, fill: '#78716c'}} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{fill: '#fff7ed'}} 
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} 
                />
                <Bar dataKey="stock" fill="#ea580c" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-primary-100 overflow-y-auto max-h-80">
          <h3 className="text-lg font-semibold text-primary-900 mb-4">补货清单</h3>
          {lowStockParts.length === 0 ? (
             <div className="text-center text-gray-400 py-10">所有库存充足！</div>
          ) : (
            <ul className="space-y-3">
              {lowStockParts.map(part => (
                <li key={part.id} className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                  <div>
                    <p className="font-medium text-red-900">{part.name}</p>
                    <p className="text-xs text-red-700">位置: {part.location}</p>
                  </div>
                  <div className="text-right">
                    <span className="block text-xl font-bold text-red-600">{part.stock}</span>
                    <span className="text-xs text-red-500">警戒线: {part.minStockThreshold}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;