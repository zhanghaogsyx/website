import React, { useState, useRef } from 'react';
import { Part } from '../types';
import { Plus, Trash2, Edit2, Search, MapPin, Upload, X } from 'lucide-react';

interface InventoryListProps {
  parts: Part[];
  onAddPart: (part: Part) => void;
  onUpdatePart: (part: Part) => void;
  onDeletePart: (id: string) => void;
}

const InventoryList: React.FC<InventoryListProps> = ({ parts, onAddPart, onUpdatePart, onDeletePart }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPart, setEditingPart] = useState<Part | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<Part>>({
    name: '',
    category: '',
    stock: 0,
    unit: '个',
    location: '',
    minStockThreshold: 10,
    imageUrl: ''
  });

  const filteredParts = parts.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenModal = (part?: Part) => {
    if (part) {
      setEditingPart(part);
      setFormData(part);
    } else {
      setEditingPart(null);
      setFormData({
        name: '',
        category: '通用',
        stock: 0,
        unit: '个',
        location: '地板/待整理',
        minStockThreshold: 10,
        imageUrl: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData({ ...formData, imageUrl: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingPart) {
      onUpdatePart({ ...editingPart, ...formData } as Part);
    } else {
      onAddPart({
        id: crypto.randomUUID(),
        ...formData
      } as Part);
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-primary-900">零件库存</h2>
          <p className="text-primary-700">管理您的原材料、珠子和配件。</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-full flex items-center gap-2 shadow-lg transition-all"
        >
          <Plus size={20} />
          添加新零件
        </button>
      </header>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
        <input 
          type="text" 
          placeholder="搜索零件名称或分类..." 
          className="w-full pl-10 pr-4 py-3 rounded-xl border border-primary-200 focus:outline-none focus:ring-2 focus:ring-primary-500 bg-white/80"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Grid View */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredParts.map(part => (
          <div key={part.id} className="bg-white p-4 rounded-xl shadow-sm border border-primary-100 hover:border-primary-300 transition-all flex gap-4">
            {/* Image Thumbnail */}
            <div className="w-20 h-20 shrink-0 bg-gray-100 rounded-lg overflow-hidden border border-gray-200 relative">
              {part.imageUrl ? (
                <img src={part.imageUrl} alt={part.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-300 bg-gray-50">
                  <div className="text-xs text-center">无图</div>
                </div>
              )}
            </div>

            <div className="flex-1 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start">
                  <span className="inline-block px-2 py-0.5 bg-primary-50 text-primary-700 text-xs rounded-md font-medium">
                    {part.category}
                  </span>
                  <div className="flex gap-2 text-gray-400">
                    <button onClick={() => handleOpenModal(part)} className="hover:text-primary-600">
                      <Edit2 size={16} />
                    </button>
                    <button onClick={() => onDeletePart(part.id)} className="hover:text-red-500">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
                <h3 className="text-lg font-bold text-gray-800 leading-tight my-1">{part.name}</h3>
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <MapPin size={12} />
                  {part.location || "无位置"}
                </div>
              </div>
              
              <div className="flex justify-between items-end mt-2">
                <div>
                  <span className={`text-xl font-bold ${part.stock <= part.minStockThreshold ? 'text-red-600' : 'text-gray-800'}`}>
                    {part.stock} <span className="text-sm font-normal text-gray-500">{part.unit}</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              {editingPart ? '编辑零件' : '添加新零件'}
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Image Upload Area */}
              <div className="flex flex-col items-center mb-4">
                <div 
                  className="w-full h-40 border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-primary-500 bg-gray-50 relative overflow-hidden group transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {formData.imageUrl ? (
                    <>
                      <img src={formData.imageUrl} alt="Preview" className="w-full h-full object-contain" />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-white text-sm font-bold bg-black/50 px-3 py-1 rounded-full">点击更换图片</span>
                      </div>
                    </>
                  ) : (
                    <>
                      <Upload size={32} className="text-gray-400 mb-2" />
                      <span className="text-sm text-gray-500">点击上传零件图片</span>
                    </>
                  )}
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleImageUpload} 
                  />
                </div>
                {formData.imageUrl && (
                  <button 
                    type="button"
                    onClick={() => setFormData({...formData, imageUrl: ''})}
                    className="mt-2 text-sm text-red-500 hover:text-red-700 flex items-center gap-1"
                  >
                    <X size={14} /> 删除图片
                  </button>
                )}
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-800 mb-1">名称</label>
                <input 
                  required
                  type="text" 
                  className="w-full p-2 bg-white text-black border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none font-medium"
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  placeholder="例如: 红色水晶珠"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                   <label className="block text-sm font-bold text-gray-800 mb-1">分类</label>
                   <input 
                    type="text" 
                    list="categories"
                    className="w-full p-2 bg-white text-black border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none font-medium"
                    value={formData.category}
                    onChange={e => setFormData({...formData, category: e.target.value})}
                    placeholder="分类"
                  />
                  <datalist id="categories">
                    <option value="珠子" />
                    <option value="链条" />
                    <option value="扣环" />
                    <option value="吊坠/挂件" />
                    <option value="包装材料" />
                  </datalist>
                </div>
                <div>
                   <label className="block text-sm font-bold text-gray-800 mb-1">位置</label>
                   <input 
                    type="text" 
                    placeholder="位置"
                    className="w-full p-2 bg-white text-black border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none font-medium"
                    value={formData.location}
                    onChange={e => setFormData({...formData, location: e.target.value})}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                   <label className="block text-sm font-bold text-gray-800 mb-1">库存</label>
                   <input 
                    type="number" 
                    className="w-full p-2 bg-white text-black border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none font-medium"
                    value={formData.stock}
                    onChange={e => setFormData({...formData, stock: parseInt(e.target.value) || 0})}
                  />
                </div>
                <div>
                   <label className="block text-sm font-bold text-gray-800 mb-1">单位</label>
                   <select 
                    className="w-full p-2 bg-white text-black border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none font-medium"
                    value={formData.unit}
                    onChange={e => setFormData({...formData, unit: e.target.value})}
                   >
                     <option value="个">个</option>
                     <option value="克">克</option>
                     <option value="米">米</option>
                     <option value="包">包</option>
                   </select>
                </div>
                 <div>
                   <label className="block text-sm font-bold text-gray-800 mb-1">预警线</label>
                   <input 
                    type="number" 
                    className="w-full p-2 bg-white text-black border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none font-medium"
                    value={formData.minStockThreshold}
                    onChange={e => setFormData({...formData, minStockThreshold: parseInt(e.target.value) || 0})}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-6">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
                >
                  取消
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 shadow-md font-medium"
                >
                  保存
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default InventoryList;