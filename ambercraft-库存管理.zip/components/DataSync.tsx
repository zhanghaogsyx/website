import React, { useState } from 'react';
import { exportData, importData } from '../services/storageService';
import { Download, Upload, CheckCircle, AlertCircle, Share2 } from 'lucide-react';

const DataSync: React.FC = () => {
  const [importStatus, setImportStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleExport = () => {
    const dataStr = exportData();
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `ambercraft_backup_${new Date().toISOString().slice(0,10)}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files.length > 0) {
      fileReader.readAsText(e.target.files[0], "UTF-8");
      fileReader.onload = (event) => {
        if (event.target?.result) {
          const success = importData(event.target.result as string);
          setImportStatus(success ? 'success' : 'error');
          if (success) {
            setTimeout(() => window.location.reload(), 1500); // Reload to reflect changes
          }
        }
      };
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <header>
        <h2 className="text-3xl font-bold text-primary-900">同步与分享</h2>
        <p className="text-primary-700">在不同设备间迁移数据，或分享给他人。</p>
      </header>

      <div className="bg-white p-8 rounded-2xl shadow-sm border border-primary-100 space-y-8">
        
        {/* Export Section */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-gray-100">
          <div className="flex-1">
             <div className="flex items-center gap-3 mb-2">
               <div className="p-2 bg-blue-100 text-blue-600 rounded-lg"><Share2 size={20}/></div>
               <h3 className="font-bold text-gray-900">导出数据 (分享)</h3>
             </div>
             <p className="text-sm text-gray-500">将您的所有库存数据下载为一个文件。您可以将此文件发送给合作伙伴，或复制到U盘在另一台电脑上使用。</p>
          </div>
          <button 
            onClick={handleExport}
            className="bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg flex items-center gap-2 whitespace-nowrap"
          >
            <Download size={18} />
            下载数据文件
          </button>
        </div>

        {/* Import Section */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
           <div className="flex-1">
             <div className="flex items-center gap-3 mb-2">
               <div className="p-2 bg-green-100 text-green-600 rounded-lg"><Upload size={20}/></div>
               <h3 className="font-bold text-gray-900">导入数据</h3>
             </div>
             <p className="text-sm text-gray-500">从备份恢复或加载另一台设备的数据。<br/><span className="text-red-500 font-medium">警告：这将覆盖当前的库存数据。</span></p>
          </div>
          <div className="relative group">
            <input 
              type="file" 
              accept=".json"
              onChange={handleImport}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
            />
            <button className="bg-white border-2 border-dashed border-gray-300 text-gray-600 font-semibold py-3 px-6 rounded-xl hover:border-primary-500 hover:text-primary-600 transition-colors flex items-center gap-2 whitespace-nowrap">
              <Upload size={18} />
              选择文件
            </button>
          </div>
        </div>

        {/* Status Messages */}
        {importStatus === 'success' && (
          <div className="p-4 bg-green-50 text-green-700 rounded-xl flex items-center gap-2 animate-pulse">
            <CheckCircle size={20} />
            导入成功！正在刷新页面...
          </div>
        )}
        {importStatus === 'error' && (
          <div className="p-4 bg-red-50 text-red-700 rounded-xl flex items-center gap-2">
            <AlertCircle size={20} />
            导入失败。文件可能已损坏。
          </div>
        )}
      </div>
    </div>
  );
};

export default DataSync;