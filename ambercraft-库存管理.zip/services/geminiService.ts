import { GoogleGenAI, Type } from "@google/genai";
import { Part, Product } from '../types';

const getAiClient = () => {
  // In a real app, this should be handled securely. 
  // For this generated code, we rely on the environment variable as per instructions.
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please select a valid API key.");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

/**
 * Analyzes a jewelry product image to decompose it into potential parts.
 */
export const analyzeProductImage = async (base64Image: string): Promise<any> => {
  const ai = getAiClient();
  const model = "gemini-2.5-flash";

  const prompt = `
    你是一个专业的手工饰品制作助手。
    分析这张手工饰品的图片。
    将其分解为各个组成零件（珠子、链条、扣环、吊坠等）。
    预估每个零件的数量。
    并提供一段关于该饰品风格的中文简短描述。
  `;

  // Remove data:image/...;base64, prefix if present
  const base64Data = base64Image.includes('base64,') 
    ? base64Image.split('base64,')[1] 
    : base64Image;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg', // Assuming jpeg/png for simplicity, API handles most
              data: base64Data
            }
          },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            description: { type: Type.STRING },
            parts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: "组件的名称 (中文), 例如 '4mm 红色水晶珠'" },
                  estimatedQuantity: { type: Type.NUMBER },
                  material: { type: Type.STRING, description: "材质 (中文)" },
                  category: { type: Type.STRING, description: "例如 '珠子', '金属配件', '线材'" }
                }
              }
            }
          }
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};

/**
 * Suggests storage optimization based on current inventory list.
 */
export const suggestStorageOptimization = async (parts: Part[]): Promise<string> => {
  const ai = getAiClient();
  const model = "gemini-2.5-flash"; // Flash is sufficient for text reasoning of this scale

  const inventorySummary = parts.map(p => 
    `- ${p.name} (数量: ${p.stock}, 分类: ${p.category}, 当前位置: ${p.location})`
  ).join('\n');

  const prompt = `
    我经营一家手工饰品生意。目前的库存很乱，大部分都在地上或者随便装在袋子里。
    这是我目前的零件清单：
    ${inventorySummary}

    请扮演一位专业的收纳整理师。为这些物品建议一套具体、优化的收纳系统（例如特定类型的盒子、抽屉、立式架子等）。
    请按逻辑对它们进行分类或按使用频率分组。
    请用简体中文输出建议，格式为 Markdown。
    重点关注适合小型工作室的低成本、高效率解决方案。
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Storage Advice Error:", error);
    return "抱歉，目前无法生成收纳建议，请稍后再试。";
  }
};