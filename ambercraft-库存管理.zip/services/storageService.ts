import { Part, Product } from '../types';

const KEYS = {
  PARTS: 'ambercraft_parts',
  PRODUCTS: 'ambercraft_products',
};

// --- Parts ---

export const getParts = (): Part[] => {
  const data = localStorage.getItem(KEYS.PARTS);
  return data ? JSON.parse(data) : [];
};

export const savePart = (part: Part): void => {
  const parts = getParts();
  const index = parts.findIndex((p) => p.id === part.id);
  if (index >= 0) {
    parts[index] = part;
  } else {
    parts.push(part);
  }
  localStorage.setItem(KEYS.PARTS, JSON.stringify(parts));
};

export const deletePart = (id: string): void => {
  const parts = getParts().filter((p) => p.id !== id);
  localStorage.setItem(KEYS.PARTS, JSON.stringify(parts));
};

// --- Products ---

export const getProducts = (): Product[] => {
  const data = localStorage.getItem(KEYS.PRODUCTS);
  return data ? JSON.parse(data) : [];
};

export const saveProduct = (product: Product): void => {
  const products = getProducts();
  const index = products.findIndex((p) => p.id === product.id);
  if (index >= 0) {
    products[index] = product;
  } else {
    products.push(product);
  }
  localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
};

export const deleteProduct = (id: string): void => {
  const products = getProducts().filter((p) => p.id !== id);
  localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
};

// --- Data Management (Export/Import) ---

export const exportData = (): string => {
  const data = {
    parts: getParts(),
    products: getProducts(),
    exportedAt: new Date().toISOString(),
  };
  return JSON.stringify(data, null, 2);
};

export const importData = (jsonString: string): boolean => {
  try {
    const data = JSON.parse(jsonString);
    if (Array.isArray(data.parts)) {
      localStorage.setItem(KEYS.PARTS, JSON.stringify(data.parts));
    }
    if (Array.isArray(data.products)) {
      localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(data.products));
    }
    return true;
  } catch (e) {
    console.error("Failed to import data", e);
    return false;
  }
};
